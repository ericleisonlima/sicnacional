<?php

class MunicipioRecord extends TRecord {
    
    const TABLENAME = "municipio";
    const PRIMARYKEY = "id";
    const IDPOLICY = "serial";

}
